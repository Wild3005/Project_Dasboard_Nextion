/*
 * dfplayer.c
 *
 *  Created on: Apr 11, 2025
 *      Author: nakanomiku
 */

#include "dfplayer.h"

// Helper function to calculate checksum
static uint16_t DFPlayer_CalculateChecksum(uint8_t *data, uint8_t length)
{
    uint16_t sum = 0;
    for (uint8_t i = 1; i < length - 2; i++) // Exclude start byte and end byte
    {
        sum += data[i];
    }
    return 0xFFFF - sum + 1;
}

// Function to send a command
void DFPlayer_SendCmd(DFPlayer_Command command, uint8_t param1, uint8_t param2)
{
    uint8_t packet[10];
    packet[0] = START_BYTE;
    packet[1] = VERSION;
    packet[2] = LENGTH;
    packet[3] = command;
    packet[4] = FEEDBACK;
    packet[5] = param1;
    packet[6] = param2;

    uint16_t checksum = DFPlayer_CalculateChecksum(packet, 10);
    packet[7] = (checksum >> 8) & 0xFF; // High byte of checksum
    packet[8] = checksum & 0xFF;       // Low byte of checksum
    packet[9] = END_BYTE;

    HAL_UART_Transmit(DF_uart, packet, sizeof(packet), HAL_MAX_DELAY);
}

// Initialization function
void DFPlayer_Init(PlaybackSource source, uint8_t volume)
{
    // Set playback source
    DFPlayer_SendCmd(CMD_SPECIFY_PLAYBACK_SOURCE, 0, source);
    HAL_Delay(200); 
    // Set volume
    DFPlayer_SendCmd(CMD_SPECIFY_VOLUME, 0, volume);
    HAL_Delay(500);
}

// Function to play the next track
void DFPlayer_PlayNext(void)
{
    DFPlayer_SendCmd(CMD_NEXT, 0, 0);
}

// Function to play the previous track
void DFPlayer_PlayPrevious(void)
{
    DFPlayer_SendCmd(CMD_PREVIOUS, 0, 0);
//    HAL_Delay(200);
}

// Function to pause playback
void DFPlayer_Pause(void)
{
    DFPlayer_SendCmd(CMD_PAUSE, 0, 0);
//    HAL_Delay(200);
}

// Function to play a specific track
void DFPlayer_PlayTrack(uint16_t trackNumber)
{
    DFPlayer_SendCmd(CMD_SPECIFY_TRACKING, (trackNumber >> 8) & 0xFF, trackNumber & 0xFF);
//    HAL_Delay(200);
}
