/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  * @author  : Muhammad Hafidzh EE ITS 22
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "fdcan.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "stdio.h"
#include "dfplayer.h"
#include "nextion.h"
#include "stdbool.h"
//#include "stepper.h"

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

typedef struct {
    struct {
        //0x260
        int16_t pwm;
        uint16_t torque; //adc
    } eps_data;

    struct {
        //0x261
        float ecu_temp; // celcius
        uint16_t accelerator_pedal; // adc
        float vel_car; // km/h
    } ecu_data;

    struct {
        //0x262
        float bus_voltage; // volt
        float bus_current; // ampere
        float phase_current; // ampere
        int16_t speed_rpm; // rpm
        
        //0x263
        float controller_temp; // celcius
        float motor_temp; // celcius
        uint8_t status; // status bit
        uint8_t error1; // error bit
        uint8_t error2; // error bit
        uint8_t error3; // error bit
        uint8_t life_signal; // life signal bit
    } motor_data;
    
    struct {
        //0x1806E5F
        float charger_voltage; // volt scale 0.1
        float charger_current; // ampere scale 0.1
        uint8_t control_charger; // 0x00 off, 0x01 on

        //0x02018100
        float total_voltage; // volt scale 0.01
        float current; // ampere scale 0.1 offsett 1000
        uint16_t soc; // scale 1%
        uint16_t ah; // scale 0.01 ah

        //0x02028100
        uint16_t soh; // scale 1%
        uint16_t running_time; // hour 
        uint16_t cycle_times; 

        //0x02038100
        uint16_t battery_protect_info;
        uint16_t battery_pack_status;

        //0x02048100
        float vmax; // mvolt
        float vmin; // mvolt
        uint8_t vmax_num; // nomor sel dengan tegangan maksimum
        uint8_t vmin_num; // nomor sel dengan tegangan minimum

        //0x02058100
        float max_temp; // celcius scale 0.1 offset 40
        float min_temp; // celcius scale 0.1 offset 40

        //0x02068100
        float t1; // celcius scale 0.1 offset 40
        float t2; // celcius scale 0.1 offset 40
        float t3; // celcius scale 0.1 offset 40

        //0x02108100 - 0x02178100
        float cell[32]; // mvolt
    } bms_data;


    uint8_t buffEPS[8]; // Buffer untuk data EPS
    uint8_t buffECU[8]; // Buffer untuk data ECU
    uint8_t buffMotor1[8]; // Buffer untuk data Motor
    uint8_t buffMotor2[8]; // Buffer untuk data Motor 2
    uint8_t buffCharger[8]; // Buffer untuk data Charger
    uint8_t buffBMS_soc[8]; // Buffer untuk data BMS SOC
    uint8_t buffBMS_soh[8]; // Buffer untuk data BMS SOH
    uint8_t buffBMS_status[8]; // Buffer untuk data BMS Status
    uint8_t buffBMS_vmax_vmin[8]; // Buffer untuk data BMS Vmax Vmin
    uint8_t buffBMS_temp_max_min[8]; // Buffer untuk data BMS Temp Max Min
    uint8_t buffBMS_temp[8]; // Buffer untuk data BMS Temp
    uint8_t buffBMS_cell_1_4[8]; // Buffer untuk data BMS Cell 1-4
    uint8_t buffBMS_cell_5_8[8]; // Buffer untuk data BMS Cell 5-8
    uint8_t buffBMS_cell_9_12[8]; // Buffer untuk data BMS Cell 9-12
    uint8_t buffBMS_cell_13_16[8]; // Buffer untuk data BMS Cell 13-16
    uint8_t buffBMS_cell_17_20[8]; // Buffer untuk data BMS Cell 17-20
    uint8_t buffBMS_cell_21_24[8]; // Buffer untuk data BMS Cell 21-24
    // uint8_t buffBMS_cell_25_28[8]; // Buffer untuk data BMS Cell 25-28
    // uint8_t buffBMS_cell_29_32[8]; // Buffer untuk data BMS Cell 29-32
} can_recv_t;

can_recv_t can_recv;
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
int indx = 0;

uint8_t sen_kanan = 0;

uint16_t num_music;
uint8_t play = 0;

uint8_t cmd_end[3] = {0xFF, 0xFF, 0xFF};


//1 dia mati 0 dia nyala (active low) kecuali si lampu jauh berlawanan sama dim
bool dim=1;
bool reting_ka=1;
bool reting_ki=1;
bool wp_speed1=1;
bool wp_speed2=1;
bool lampu_dekat=1;
bool lampu_jauh=1;
bool wp_interval=1;
bool pompa=1;
bool lm_wp=1;

bool bell = 1;

uint8_t wp_state = 0;
uint8_t mode = 0;

uint32_t last_time = 0;   // Timer for non-blocking delay
uint8_t damn = 0; 

int odom = 0;
uint8_t flag = 0;

uint32_t timer_ret = 0;

int tes = 0;
uint8_t wp_test = 0;

void flush_uart()
{
    uint8_t dump;
    while (HAL_UART_Receive(&huart8, &dump, 1, 10) == HAL_OK) {}
}

uint16_t rpm;

uint32_t timer_s = 0;

uint32_t ctr = 0;

/* lampu dekat //D ada off trus kota 
  lampu jauh =D
  lampu kota \\D//
  nyala itu harus di gambar bohlam 

  wiper tu ada off 
  int 
  low
  high
  trus klo di dorong ke dalam itu nnti pompa

  bt0 lampu kota
  bt1 lampu dekat
  bt4 lampu jauh
  bt3 wiper nnti kedap kedipnya berdasarkan mode int lo apa hi
  bt2 pompa klo nyala 
   
*/

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

void send_string (char *id, char *string)
{
	char buffer[50];
	int len = sprintf(buffer, "%s.txt=\"%s\"", id, string);
	HAL_UART_Transmit(&huart8, (uint8_t *)buffer, len, 1000);
	HAL_UART_Transmit(&huart8, cmd_end, 3, 100);
}

//void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
//{
//  if (htim->Instance == TIM6)
//  {
//
//#define TIM6_PERIOD 0.001 // 1 ms or 1 kHz masih blum 1khz ntar benerin
//	if(++ctr > 100 && flag == 3)
//	{
//	  nextion.set_num_val(1, 200+odom);
//	  nextion.send_command("wepo n1.val,10");
//	  flag = 4;
//	}
//    timer_ret++;
//    if(timer_ret > 300)
//    {
//      //reting_ka = 1 reting_ki = 1; // mati semua
//      //reting_ka = 0 reting_ki = 0; // kedip dua2nya
//      //reting_ka = 1 reting_ki = 0; // ka mati ki hidup
//      // reting_ka = 0 reting_ki = 1; // ka hidup ki mati
//      if(HAL_GPIO_ReadPin(GPIOE, SW_RETKA_Pin) == 1 && HAL_GPIO_ReadPin(GPIOB, SW_RETKI_Pin) == 1)
//      {
//        DFPlayer_Pause();
//        reting_ka = 1;
//        reting_ki = 1;
//        nextion.set_DSbutton_value(6, !reting_ka);
//        nextion.set_DSbutton_value(5, !reting_ki);
//        HAL_GPIO_WritePin(RETKA_GPIO_Port, RETKA_Pin, !reting_ka);
//        HAL_GPIO_WritePin(RETKI_GPIO_Port, RETKI_Pin, !reting_ki);
//      }
//      else if(HAL_GPIO_ReadPin(GPIOE, SW_RETKA_Pin) == 0 && HAL_GPIO_ReadPin(GPIOB, SW_RETKI_Pin) == 0)
//      {
//        reting_ka = !reting_ka;
//        reting_ki = !reting_ki;
//        nextion.set_DSbutton_value(6, !reting_ka);
//        nextion.set_DSbutton_value(5, !reting_ki);
//        HAL_GPIO_WritePin(RETKA_GPIO_Port, RETKA_Pin, !reting_ka);
//        HAL_GPIO_WritePin(RETKI_GPIO_Port, RETKI_Pin, !reting_ki);
//      }
//      else if(HAL_GPIO_ReadPin(GPIOE, SW_RETKA_Pin) == 1 && HAL_GPIO_ReadPin(GPIOB, SW_RETKI_Pin) == 0)
//      {
//        reting_ka = 1;
//        reting_ki = !reting_ki;
//        nextion.set_DSbutton_value(6, !reting_ka);
//        nextion.set_DSbutton_value(5, !reting_ki);
//        HAL_GPIO_WritePin(RETKA_GPIO_Port, RETKA_Pin, !reting_ka);
//        HAL_GPIO_WritePin(RETKI_GPIO_Port, RETKI_Pin, !reting_ki);
//        if(reting_ki)
//        DFPlayer_PlayTrack(5);
//        else
//        DFPlayer_Pause();
//      }
//      else if(HAL_GPIO_ReadPin(GPIOE, SW_RETKA_Pin) == 0 && HAL_GPIO_ReadPin(GPIOB, SW_RETKI_Pin) == 1)
//      {
//        reting_ka = !reting_ka;
//        reting_ki = 1;
//        nextion.set_DSbutton_value(6, !reting_ka);
//        nextion.set_DSbutton_value(5, !reting_ki);
//        HAL_GPIO_WritePin(RETKA_GPIO_Port, RETKA_Pin, !reting_ka);
//        HAL_GPIO_WritePin(RETKI_GPIO_Port, RETKI_Pin, !reting_ki);
//        if(reting_ka)
//        DFPlayer_PlayTrack(5);
//        else
//        DFPlayer_Pause();
//      }
//
//      timer_ret = 0;
//    }
//
//    //1 dia mati 0 nyala
//    if (HAL_GPIO_ReadPin(SW_BEL_GPIO_Port, SW_BEL_Pin) == 1)
//	 	{
//	 		bell = 1;
//	 		HAL_GPIO_WritePin(BELL_GPIO_Port, BELL_Pin, 0);
//
//	 	}
//	 	else
//	 	{
//	 		bell = 0;
//	 		HAL_GPIO_WritePin(BELL_GPIO_Port, BELL_Pin, 1);
//	 	}
//
//	  if (HAL_GPIO_ReadPin(GPIOB, SW_DIM_Pin)==1)
//	  {
//		  dim=1;
//	  }
//	  else
//	  {
//		  dim=0;
//	  }
//
//	  if (HAL_GPIO_ReadPin(GPIOB, SW_LJ_Pin)==1)
//	  {
//      lampu_jauh=1;
//      nextion.set_DSbutton_value(4, lampu_jauh);
//		  HAL_GPIO_WritePin(JAUH_GPIO_Port, JAUH_Pin, lampu_jauh);
//	  }
//		else
//	  {
//		  lampu_jauh=0;
//      nextion.set_DSbutton_value(4, lampu_jauh);
//		  HAL_GPIO_WritePin(JAUH_GPIO_Port, JAUH_Pin, lampu_jauh);
//	  }
//
//	  if (HAL_GPIO_ReadPin(GPIOB, SW_LD_Pin)==1)
//	  {
//		  lampu_dekat=1;
//      nextion.set_DSbutton_value(1, !lampu_dekat);
//		  HAL_GPIO_WritePin(DEKAT_GPIO_Port, DEKAT_Pin, !lampu_dekat);
//	  }
//		else
//	  {
//		  lampu_dekat=0;
//      nextion.set_DSbutton_value(1, !lampu_dekat);
//		  HAL_GPIO_WritePin(DEKAT_GPIO_Port, DEKAT_Pin, !lampu_dekat);
//	  }
//
//	  if(HAL_GPIO_ReadPin(GPIOC, LM_WIPER_Pin) == 1) //limit switch wp
//	  {
//		  wp_state = 0; //ketika di bawah
//	  }
//	  else
//	  {
//		  wp_state = 1;
//	  }
//
//	  if (HAL_GPIO_ReadPin(GPIOE, SW_WP_SPD1_Pin)==1) //low
//	  {
//		  wp_speed1=1;  //mati
//	  }
//	  else
//	  {
//		  wp_speed1=0; // nyala
//	  }
//
//	  if (HAL_GPIO_ReadPin(GPIOE, SW_WP_SPD2_Pin)==1) //High
//	  {
//		  wp_speed2=1; //mati
//	  }
//	  else
//	  {
//		  wp_speed2=0; // nyala
//	  }
//
//	  if (HAL_GPIO_ReadPin(GPIOE, SW_WP_INT_Pin)==1) //INT
//	  {
//		  wp_interval=1; //mati
//      // HAL_GPIO_WritePin(WIPER_GPIO_Port, WIPER_Pin, !wp_interval);
//	  }
//		else
//	  {
//		  wp_interval=0; //nyala
//      // HAL_GPIO_WritePin(WIPER_GPIO_Port, WIPER_Pin, !wp_interval);
//	  }
//
//
//	  if (HAL_GPIO_ReadPin(SW_POMPA_GPIO_Port, SW_POMPA_Pin) == 1)
//	  {
//		  pompa=1;
//      nextion.set_DSbutton_value(2, !pompa);
//		  HAL_GPIO_WritePin(POMPA_GPIO_Port, POMPA_Pin, !pompa);
//	  }
//	  else
//	  {
//		  pompa=0;
//      nextion.set_DSbutton_value(2, !pompa);
//		  HAL_GPIO_WritePin(POMPA_GPIO_Port, POMPA_Pin, !pompa);
//	  }
//
//    if (wp_interval == 0) mode = 1;
//    else if (wp_speed1 == 0) mode = 2;
//    else if (wp_speed2 == 0) mode = 3;
//    else mode = 0;
//
//    // Logic wiper
//    if (mode == 0)
//    {
//      if (wp_state == 0)
//      {
//          HAL_GPIO_WritePin(WIPER_GPIO_Port, WIPER_Pin, GPIO_PIN_RESET); // Matikan
//          last_time = 0;
//          damn = 10;
//      }
//      else
//      {
//          HAL_GPIO_WritePin(WIPER_GPIO_Port, WIPER_Pin, GPIO_PIN_SET);
//      }
//    }
//    else if (mode == 1)
//    {
//      if (wp_state == 0)
//      {
//        if (last_time >= 1500) // Cek apakah 1 detik telah berlalu
//        {
//            HAL_GPIO_WritePin(WIPER_GPIO_Port, WIPER_Pin, GPIO_PIN_SET);
//            damn = 1;
//        }
//        else
//        {
//            damn = 0;
//            HAL_GPIO_WritePin(WIPER_GPIO_Port, WIPER_Pin, GPIO_PIN_RESET);
//            last_time++;
//        }
//      }
//      else
//      {
//          damn = 2;
//          last_time = 0; // Reset waktu awal
//      }
//    }
//
//    else if (mode == 2)
//    {
//      if (wp_state == 0)
//      {
//        if (last_time >= 800) // Cek apakah 1 detik telah berlalu
//        {
//            HAL_GPIO_WritePin(WIPER_GPIO_Port, WIPER_Pin, GPIO_PIN_SET);
//            damn = 4;
//        }
//        else
//        {
//            damn = 3;
//            HAL_GPIO_WritePin(WIPER_GPIO_Port, WIPER_Pin, GPIO_PIN_RESET);
//            last_time++;
//        }
//      }
//      else
//      {
//          damn = 5;
//          last_time = 0; // Reset waktu awal
//      }
//    }
//
//    else if (mode == 3)
//    {
//      if (wp_state == 0)
//      {
//        HAL_GPIO_WritePin(WIPER_GPIO_Port, WIPER_Pin, GPIO_PIN_SET);
//        damn = 6;
//
//      }
//      else
//      {
//        damn = 7;
//      }
//    }
//
//
//  }
//}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_FDCAN1_Init();
  MX_UART4_Init();
  MX_UART8_Init();
  MX_TIM3_Init();
//  MX_TIM6_Init();
  /* USER CODE BEGIN 2 */
  FDCAN_FilterTypeDef sFilterConfig;
  sFilterConfig.IdType = FDCAN_STANDARD_ID;
  sFilterConfig.FilterIndex = 0;
  sFilterConfig.FilterType = FDCAN_FILTER_MASK;
  sFilterConfig.FilterConfig = FDCAN_FILTER_TO_RXFIFO0;
  sFilterConfig.FilterID1 = 0x00000000;
  sFilterConfig.FilterID2 = 0x00000000;

  HAL_StatusTypeDef config_filter_status = HAL_FDCAN_ConfigFilter(&hfdcan1, &sFilterConfig);
  if (config_filter_status != HAL_OK)
  {
    Error_Handler();
  }
  // Start the FDCAN peripheral
  HAL_StatusTypeDef start_can_status = HAL_FDCAN_Start(&hfdcan1);
  if (start_can_status != HAL_OK)
  {
    Error_Handler();
  }
  // Activate CAN interrupts for receiving messages
  HAL_FDCAN_ActivateNotification(&hfdcan1, FDCAN_IT_RX_FIFO0_NEW_MESSAGE, 0);

  // Activate CAN interrupts for receiving messages
  // HAL_FDCAN_ActivateNotification(&hfdcan1, FDCAN_IT_RX_FIFO0_NEW_MESSAGE, 0);

  DFPlayer_Init(PLAYBACK_SOURCE_TF, 30); // Initialize DFPlayer with TF card and volume 20
  HAL_Delay(1000);
  nextion.send_command("page 0");
  nextion.send_command("repo n1.val,10");
  DFPlayer_PlayTrack(1);
  HAL_Delay(3000);
  flush_uart();
  odom = nextion.get_num_val(1);
  flag = 2;


//  HAL_TIM_Base_Start_IT(&htim6); // Start timer 6 for 1ms tick
  HAL_Delay(3000);
  flag = 3;

//  TxHeader.Identifier = 0x11;
//  TxHeader.IdType = FDCAN_STANDARD_ID;
//  TxHeader.TxFrameType = FDCAN_DATA_FRAME;
//  TxHeader.DataLength = FDCAN_DLC_BYTES_64;
//  TxHeader.ErrorStateIndicator = FDCAN_ESI_ACTIVE;
//  TxHeader.BitRateSwitch = FDCAN_BRS_OFF;
////  TxHeader.FDFormat = FDCAN_CLASSIC_CAN;
//  TxHeader.FDFormat = FDCAN_FD_CAN;
//  TxHeader.TxEventFifoControl = FDCAN_NO_TX_EVENTS;
//  TxHeader.MessageMarker = 0;

//   HAL_GPIO_WritePin(M0_GPIO_Port, M0_Pin, GPIO_PIN_SET);
//   HAL_GPIO_WritePin(M1_GPIO_Port, M1_Pin, GPIO_PIN_RESET);
//   HAL_GPIO_WritePin(M2_GPIO_Port, M2_Pin, GPIO_PIN_RESET);
//
//   HAL_GPIO_WritePin(DIR_GPIO_Port, DIR_Pin, GPIO_PIN_SET);
//
//   HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_1);

  // drv8825 structure creation
//	drv8825 drv;
////
////	// drv8825 structure initialization
//	drv8825_init(&drv, DIR_GPIO_Port, DIR_Pin,
//			STEP_GPIO_Port, STEP_Pin, &htim3, TIM_CHANNEL_1);
//////	// drv8825 speed
//	drv8825_setSpeedRPM(&drv, 50);
////  flag  = 1;
//  nextion.send_command("wepo n1.val,10"); // perintah + 3 byte 0xFF
//  HAL_Delay(5);
////
//  HAL_UART_Receive(&huart8, ready, 4, 100);
//  if (ready[0] == 0x1) {
//	  flag = 1;
//      nextion.set_num_val(1, 300);
//      HAL_UART_Receive(&huart8, done, 4, 100); // tunggu 0xFD
//  }
//  nextion.set_num_val(1, odom+1);

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {

// //
// //	  for(int i=0; i < 64; i++)
// //	  {
// //		  TxData[i] = indx++;
// //	  }
// //
// //	  // Add the message to the Tx FIFO queue
// //	  HAL_FDCAN_AddMessageToTxFifoQ(&hfdcan1, &TxHeader, TxData);
// //	  HAL_Delay(1000);

// //	   HAL_Delay(10);

        if(HAL_GetTick() - 0 > 5000 && flag == 3)
        {
          nextion.set_num_val(1, 200+odom);
          nextion.send_command("wepo n1.val,10");
          flag = 4;
        }

 	 	 if (HAL_GPIO_ReadPin(SW_BEL_GPIO_Port, SW_BEL_Pin) == 1)
 	 	 {
 	 		 bell = 1;
 	 		 HAL_GPIO_WritePin(BELL_GPIO_Port, BELL_Pin, 0);

 	 	 }
 	 	 else
 	 	 {
 	 		 bell = 0;
 	 		 HAL_GPIO_WritePin(BELL_GPIO_Port, BELL_Pin, 1);
 	 	 }

 //		  if(HAL_GetTick() - timer_s > 10)
 //		  {
 //			   TIM3->CCR1 = 500;
 //			   timer_s = HAL_GetTick();
 //		  }
 	  	  // if (wp_test == 1)
 	  	  // {
 	  		//   HAL_GPIO_WritePin(WIPER_GPIO_Port, WIPER_Pin, 1);
 	  	  // }
 	  	  // else
 	  	  // {
 	  		// HAL_GPIO_WritePin(WIPER_GPIO_Port, WIPER_Pin, 0);
 	  	  // }



 //		 if (HAL_GPIO_ReadPin(GPIOE, SW_RETKA_Pin)==1)
 //		 {
 //			 reting_ka=1;
 //			 nextion.set_DSbutton_value(6, 0);
 //		 }
 //		 else
 //		 {
 //			 reting_ka=0;
 //			  nextion.set_DSbutton_value(6, 1);
 //			  HAL_Delay(500);
 //			  nextion.set_DSbutton_value(6, 0);
 //			  HAL_Delay(500);
 //		 }
 //
 //		 if (HAL_GPIO_ReadPin(GPIOB, SW_RETKI_Pin)==1)
 //		 {
 //			 reting_ki=1;
 //			 nextion.set_DSbutton_value(5, 0);
 //		 }
 //			 else
 //		 {
 //			 reting_ki=0;
 //			  nextion.set_DSbutton_value(5, 1);
 //			  HAL_Delay(500);
 //			  nextion.set_DSbutton_value(5, 0);
 //			  HAL_Delay(500);
 //		 }
    if(HAL_GetTick() - timer_ret > 300)
    {
 	 timer_ret = HAL_GetTick();
      //reting_ka = 1 reting_ki = 1; // mati semua
      //reting_ka = 0 reting_ki = 0; // kedip dua2nya
      //reting_ka = 1 reting_ki = 0; // ka mati ki hidup
       //reting_ka = 0 reting_ki = 1; // ka hidup ki mati
     if(HAL_GPIO_ReadPin(GPIOE, SW_RETKA_Pin) == 1 && HAL_GPIO_ReadPin(GPIOB, SW_RETKI_Pin) == 1)
     {
   	  DFPlayer_Pause();
   	  reting_ka = 1;
   	  reting_ki = 1;
   	  nextion.set_DSbutton_value(6, !reting_ka);
   	  nextion.set_DSbutton_value(5, !reting_ki);
   	  HAL_GPIO_WritePin(RETKA_GPIO_Port, RETKA_Pin, !reting_ka);
   	  HAL_GPIO_WritePin(RETKI_GPIO_Port, RETKI_Pin, !reting_ki);
     }
     else if(HAL_GPIO_ReadPin(GPIOE, SW_RETKA_Pin) == 0 && HAL_GPIO_ReadPin(GPIOB, SW_RETKI_Pin) == 0)
     {
   	  reting_ka = !reting_ka;
   	  reting_ki = !reting_ki;
   	  nextion.set_DSbutton_value(6, !reting_ka);
   	  nextion.set_DSbutton_value(5, !reting_ki);
   	  HAL_GPIO_WritePin(RETKA_GPIO_Port, RETKA_Pin, !reting_ka);
   	  HAL_GPIO_WritePin(RETKI_GPIO_Port, RETKI_Pin, !reting_ki);
     }
     else if(HAL_GPIO_ReadPin(GPIOE, SW_RETKA_Pin) == 1 && HAL_GPIO_ReadPin(GPIOB, SW_RETKI_Pin) == 0)
     {
   	  reting_ka = 1;
   	  reting_ki = !reting_ki;
   	  nextion.set_DSbutton_value(6, !reting_ka);
   	  nextion.set_DSbutton_value(5, !reting_ki);
   	  HAL_GPIO_WritePin(RETKA_GPIO_Port, RETKA_Pin, !reting_ka);
   	  HAL_GPIO_WritePin(RETKI_GPIO_Port, RETKI_Pin, !reting_ki);
   	  if(reting_ki)
   		 DFPlayer_PlayTrack(5);
   	  else
   		 DFPlayer_Pause();
     }
     else if(HAL_GPIO_ReadPin(GPIOE, SW_RETKA_Pin) == 0 && HAL_GPIO_ReadPin(GPIOB, SW_RETKI_Pin) == 1)
     {
   	  reting_ka = !reting_ka;
   	  reting_ki = 1;
   	  nextion.set_DSbutton_value(6, !reting_ka);
   	  nextion.set_DSbutton_value(5, !reting_ki);
   	  HAL_GPIO_WritePin(RETKA_GPIO_Port, RETKA_Pin, !reting_ka);
   	  HAL_GPIO_WritePin(RETKI_GPIO_Port, RETKI_Pin, !reting_ki);
   	  if(reting_ka)
   		 DFPlayer_PlayTrack(5);
   	  else
   		 DFPlayer_Pause();
     }

    }

     //1 dia mati 0 nyala

 	 if (HAL_GPIO_ReadPin(GPIOB, SW_DIM_Pin)==1)
 	 {
 		 dim=1;
 	 }
 	 else
 	 {
 		 dim=0;
 	 }

 	 if (HAL_GPIO_ReadPin(GPIOB, SW_LJ_Pin)==1)
 	 {
 		 lampu_jauh=1;
     nextion.set_DSbutton_value(4, lampu_jauh);
 		 HAL_GPIO_WritePin(JAUH_GPIO_Port, JAUH_Pin, lampu_jauh);
 	 }
 		 else
 	 {
 		 lampu_jauh=0;
     nextion.set_DSbutton_value(4, lampu_jauh);
 		 HAL_GPIO_WritePin(JAUH_GPIO_Port, JAUH_Pin, lampu_jauh);
 	 }

 	 if (HAL_GPIO_ReadPin(GPIOB, SW_LD_Pin)==1)
 	 {
 		 lampu_dekat=1;
     nextion.set_DSbutton_value(1, !lampu_dekat);
 		 HAL_GPIO_WritePin(DEKAT_GPIO_Port, DEKAT_Pin, !lampu_dekat);
 	 }
 		 else
 	 {
 		 lampu_dekat=0;
     nextion.set_DSbutton_value(1, !lampu_dekat);
 		 HAL_GPIO_WritePin(DEKAT_GPIO_Port, DEKAT_Pin, !lampu_dekat);
 	 }

 	 if(HAL_GPIO_ReadPin(GPIOC, LM_WIPER_Pin) == 1) //limit switch wp
 	 {
 		 wp_state = 0; //ketika di bawah
 	 }
 	 else
 	 {
 		 wp_state = 1;
 	 }

 	 if (HAL_GPIO_ReadPin(GPIOE, SW_WP_SPD1_Pin)==1) //low
 	 {
 		 wp_speed1=1;  //mati
 	 }
 	 else
 	 {
 		 wp_speed1=0; // nyala
 	 }

 	 if (HAL_GPIO_ReadPin(GPIOE, SW_WP_SPD2_Pin)==1) //High
 	 {
 		 wp_speed2=1; //mati
 	 }
 	 else
 	 {
 		 wp_speed2=0; // nyala
 	 }

 	 if (HAL_GPIO_ReadPin(GPIOE, SW_WP_INT_Pin)==1) //INT
 	 {
 		 wp_interval=1; //mati
 //		  HAL_GPIO_WritePin(WIPER_GPIO_Port, WIPER_Pin, !wp_interval);

 	 }
 		 else
 	 {
 		 wp_interval=0; //nyala
 //		  HAL_GPIO_WritePin(WIPER_GPIO_Port, WIPER_Pin, !wp_interval);
 	 }


 	 if (HAL_GPIO_ReadPin(SW_POMPA_GPIO_Port, SW_POMPA_Pin) == 1)
 	 {
 		 pompa=1;
     nextion.set_DSbutton_value(2, !pompa);
 		 HAL_GPIO_WritePin(POMPA_GPIO_Port, POMPA_Pin, !pompa);
 	 }
 	 else
 	 {
 		 pompa=0;
     nextion.set_DSbutton_value(2, !pompa);
 		 HAL_GPIO_WritePin(POMPA_GPIO_Port, POMPA_Pin, !pompa);
 	 }

 if (wp_interval == 0) mode = 1;
 else if (wp_speed1 == 0) mode = 2;
 else if (wp_speed2 == 0) mode = 3;
 else mode = 0;

 // Logic wiper
 if (mode == 0)
 {
    if (wp_state == 0)
    {
        HAL_GPIO_WritePin(WIPER_GPIO_Port, WIPER_Pin, GPIO_PIN_RESET); // Matikan
        last_time = 0;
        damn = 10;
    }
    else
    {
        HAL_GPIO_WritePin(WIPER_GPIO_Port, WIPER_Pin, GPIO_PIN_SET);
    }
 }
 else if (mode == 1)
 {
    if (wp_state == 0)
    {
        if (HAL_GetTick() - last_time >= 1500) // Cek apakah 1 detik telah berlalu
        {
            HAL_GPIO_WritePin(WIPER_GPIO_Port, WIPER_Pin, GPIO_PIN_SET);
            damn = 1;
        }
        else
        {
            damn = 0;
            HAL_GPIO_WritePin(WIPER_GPIO_Port, WIPER_Pin, GPIO_PIN_RESET);
        }
    }
    else
    {
        damn = 2;
        last_time = HAL_GetTick(); // Reset waktu awal
    }
 }

 else if (mode == 2)
 {
    if (wp_state == 0)
    {
        if (HAL_GetTick() - last_time >= 800) // Cek apakah 1 detik telah berlalu
        {
            HAL_GPIO_WritePin(WIPER_GPIO_Port, WIPER_Pin, GPIO_PIN_SET);
            damn = 4;
        }
        else
        {
            damn = 3;
            HAL_GPIO_WritePin(WIPER_GPIO_Port, WIPER_Pin, GPIO_PIN_RESET);
        }
    }
    else
    {
        damn = 5;
        last_time = HAL_GetTick(); // Reset waktu awal
    }
 }

 else if (mode == 3)
 {
    if (wp_state == 0)
    {
      HAL_GPIO_WritePin(WIPER_GPIO_Port, WIPER_Pin, GPIO_PIN_SET);
      damn = 6;

    }
    else
    {
        damn = 7;
    }
 }




//    nextion.set_text(0, "hello");
//    HAL_Delay(1000);
//    nextion.set_text(0, "hai");
//    HAL_Delay(1000);
//	  send_string("t0", "hello");
//	  HAL_Delay(1000);
//	  send_string("t0", "hai");
//	  HAL_Delay(1000);
//    if(play == 0)
//    {
//      switch (num_music)
//        {
//          case 0:
//            DFPlayer_Pause();
//            play = 1;
//            break;
//          case 1:
//            DFPlayer_PlayTrack(1);
//            play = 1;
//            break;
//          case 2:
//            DFPlayer_PlayTrack(2);
//            play = 1;
//            break;
//          case 3:
//            DFPlayer_PlayTrack(3);
//            play = 1;
//            break;
//        }
//    }
//HAL_Delay(1);
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Supply configuration update enable
  */
  HAL_PWREx_ConfigSupply(PWR_LDO_SUPPLY);

  /** Configure the main internal regulator output voltage
  */
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE0);

  while(!__HAL_PWR_GET_FLAG(PWR_FLAG_VOSRDY)) {}

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 1;
  RCC_OscInitStruct.PLL.PLLN = 68;
  RCC_OscInitStruct.PLL.PLLP = 1;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  RCC_OscInitStruct.PLL.PLLR = 2;
  RCC_OscInitStruct.PLL.PLLRGE = RCC_PLL1VCIRANGE_3;
  RCC_OscInitStruct.PLL.PLLVCOSEL = RCC_PLL1VCOWIDE;
  RCC_OscInitStruct.PLL.PLLFRACN = 6144;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2
                              |RCC_CLOCKTYPE_D3PCLK1|RCC_CLOCKTYPE_D1PCLK1;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.SYSCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB3CLKDivider = RCC_APB3_DIV2;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_APB1_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_APB2_DIV2;
  RCC_ClkInitStruct.APB4CLKDivider = RCC_APB4_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */
void HAL_FDCAN_RxFifo0Callback(FDCAN_HandleTypeDef *hfdcan, uint32_t RxFifo0ITs)
{
  FDCAN_RxHeaderTypeDef RxHeader;
  uint8_t RxData[8];
  if (hfdcan == &hfdcan1 && (RxFifo0ITs & FDCAN_IT_RX_FIFO0_NEW_MESSAGE))
  {
    // Retrieve the received message
    HAL_FDCAN_GetRxMessage(hfdcan, FDCAN_RX_FIFO0, &RxHeader, RxData);

    //buffer all data
    if (RxHeader.Identifier == 0x260)
    {
      for (int i = 0; i < 8; i++)
      {
        can_recv.buffEPS[i] = RxData[i];
      }
    }

    else if (RxHeader.Identifier == 0x261)
    {
      for (int i = 0; i < 8; i++)
      {
        can_recv.buffECU[i] = RxData[i];
      }
    }

    else if (RxHeader.Identifier == 0x262)
    {
      for (int i = 0; i < 8; i++)
      {
        can_recv.buffMotor1[i] = RxData[i];
      }
    }

    else if (RxHeader.Identifier == 0x263)
    {
      for (int i = 0; i < 8; i++)
      {
        can_recv.buffMotor2[i] = RxData[i];
      }
    }

    else if (RxHeader.Identifier == 0x1806E5F)
    {
      for (int i = 0; i < 8; i++)
      {
        can_recv.buffCharger[i] = RxData[i];
      }
    }

    else if (RxHeader.Identifier == 0x02018100)
    {
      for (int i = 0; i < 8; i++)
      {
        can_recv.buffBMS_soc[i] = RxData[i];
      }
    }

    else if (RxHeader.Identifier == 0x02028100)
    {
      for (int i = 0; i < 8; i++)
      {
        can_recv.buffBMS_soh[i] = RxData[i];
      }
    }

    else if (RxHeader.Identifier == 0x02038100)
    {
      for (int i = 0; i < 8; i++)
      {
        can_recv.buffBMS_status[i] = RxData[i];
      }
    }

    else if (RxHeader.Identifier == 0x02048100)
    {
      for (int i = 0; i < 8; i++)
      {
        can_recv.buffBMS_vmax_vmin[i] = RxData[i];
      }
    }

    else if (RxHeader.Identifier == 0x02058100)
    {
      for (int i = 0; i < 8; i++)
      {
        can_recv.buffBMS_temp_max_min[i] = RxData[i];
      }
    }

    else if (RxHeader.Identifier == 0x02068100)
    {
      for (int i = 0; i < 8; i++)
      {
        can_recv.buffBMS_temp[i] = RxData[i];
      }
    }

    else if (RxHeader.Identifier == 0x02108100)
    {
      for (int i = 0; i < 8; i++)
      {
        can_recv.buffBMS_cell_1_4[i] = RxData[i];
      }
    }

    else if (RxHeader.Identifier == 0x02118100)
    {
      for (int i = 0; i < 8; i++)
      {
        can_recv.buffBMS_cell_5_8[i] = RxData[i];
      }
    }

    else if (RxHeader.Identifier == 0x02128100)
    {
      for (int i = 0; i < 8; i++)
      {
        can_recv.buffBMS_cell_9_12[i] = RxData[i];
      }
    }

    else if (RxHeader.Identifier == 0x02138100)
    {
      for (int i = 0; i < 8; i++)
      {
        can_recv.buffBMS_cell_13_16[i] = RxData[i];
      }
    }

    else if (RxHeader.Identifier == 0x02148100)
    {
      for (int i = 0; i < 8; i++)
      {
        can_recv.buffBMS_cell_17_20[i] = RxData[i];
      }
    }

    else if (RxHeader.Identifier == 0x02158100)
    {
      for (int i = 0; i < 8; i++)
      {
        can_recv.buffBMS_cell_21_24[i] = RxData[i];
      }
    }

    // else if (RxHeader.Identifier == 0x02168100)
    // {
    //   for (int i = 0; i < 8; i++)
    //   {
    //     can_recv.buffBMS_cell_25_28[i] = RxData[i];
    //   }
    // }

    // else if (RxHeader.Identifier == 0x02178100)
    // {
    //   for (int i = 0; i < 8; i++)
    //   {
    //     can_recv.buffBMS_cell_29_32[i] = RxData[i];
    //   }
    // }

  }
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
