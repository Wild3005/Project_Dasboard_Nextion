/*
 * nextion.c
 *
 *  Created on: Apr 16, 2025
 *      Author: nakanomiku
 */
#include "nextion.h"

char end_command[3] = {0xFF, 0xFF, 0xFF};

void send_command(const char *cmd)
{
    HAL_UART_Transmit(&huart8, (uint8_t *)cmd, strlen(cmd), 50);
    HAL_UART_Transmit(&huart8, (uint8_t *)&end_command, 3, 50);
}

void set_text(int id, const char *text)
{
    char cmd[50] = {0}, buffer[50] = {0};
    for (int i=0; i<50; i++) buffer[i] = text[i];
    sprintf(cmd, "t%d.txt=\"%s\"", id, buffer);
    send_command(cmd);
}

void set_num_val(int id, int value)
{
    char cmd[15] = {0};
    sprintf(cmd, "n%d.val=%d", id, value);
    send_command(cmd);
}

int recv_num(void)
{
   int number=0;
   uint8_t temp[8]={0};

   HAL_UART_Receive (&huart8, (uint8_t*)&temp, 8, 50);

   if (temp[0] == 0x71 && temp[5]==0xFF && temp[6]==0xFF && temp[7]==0xFF )
   {
      number= ((uint32_t)temp[4]<<24)|((uint32_t)temp[3]<<16)|(temp[2]<<8)|(temp[1]);
   }

   return number;
}

int get_num_val(int id)
{
   char cmd[20]={0};
   sprintf (cmd, "get n%d.val", id);
   send_command(cmd);
   return recv_num();
}

void set_float_val(int id, int value)
{
    char cmd[15] = {0};
    sprintf(cmd, "x%d.val=%d", id, value);
    send_command(cmd);
}

void set_picture(int id, int value)
{
    char cmd[15] = {0};
    sprintf(cmd, "p%d.pic=%d", id, value);
    send_command(cmd);
}

void set_button_text(int id, const char *text)
{
    char cmd[50] = {0} , buffer[50] = {0};
    for (int i=0; i<50; i++) buffer[i] = text[i];
    sprintf(cmd, "b%d.txt=\"%s\"", id, buffer);
    send_command(cmd);
}

void set_checkbox_value(int id, int value)
{
    char cmd[15] = {0};
    sprintf(cmd, "c%d.val=%d", id, value);
    send_command(cmd);
}

void set_DSbutton_value(int id, int value)
{
    char cmd[15] = {0};
    sprintf(cmd, "bt%d.val=%d", id, value);
    send_command(cmd);
}

void set_DSbutton_text(int id, const char *text)
{
    char cmd[50] = {0}, buffer[50] = {0};
    for (int i=0; i<50; i++) buffer[i] = text[i];
    sprintf(cmd, "bt%d.txt=\"%s\"", id, buffer);
    send_command(cmd);
}

void set_gauge_value(int id, int value)
{
    char cmd[15] = {0};
    sprintf(cmd, "z%d.val=%d", id, value);
    send_command(cmd);
}

void set_progressbar_value(int id, int value)
{
    char cmd[15] = {0};
    sprintf(cmd, "j%d.val=%d", id, value);
    send_command(cmd);
}

void set_radio_value(int id, int value)
{
    char cmd[15] = {0};
    sprintf(cmd, "r%d.val=%d", id, value);
    send_command(cmd);
}

void set_variable_value(int id, int value)
{
    char cmd[15] = {0};
    sprintf(cmd, "va%d.val=%d", id, value);
    send_command(cmd);
}

void set_variable_text(int id, const char *text)
{
    char cmd[50] = {0}, buffer[50] = {0};
    for (int i=0; i<50; i++) buffer[i] = text[i];
    sprintf(cmd, "va%d.txt=\"%s\"", id, buffer);
    send_command(cmd);
}

Nextion nextion = {
    .send_command = send_command,
    .set_text = set_text,
    .set_num_val = set_num_val,
	.recv_num = recv_num,
	.get_num_val = get_num_val,
    .set_float_val = set_float_val,
    .set_picture = set_picture,
    .set_button_text = set_button_text,
    .set_checkbox_value = set_checkbox_value,
    .set_DSbutton_value = set_DSbutton_value,
    .set_DSbutton_text = set_DSbutton_text,
    .set_gauge_value = set_gauge_value,
    .set_progressbar_value = set_progressbar_value,
    .set_radio_value = set_radio_value,
    .set_variable_value = set_variable_value,
    .set_variable_text = set_variable_text
};
