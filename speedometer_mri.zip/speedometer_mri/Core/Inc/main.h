/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32h7xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define SW_RETKA_Pin GPIO_PIN_2
#define SW_RETKA_GPIO_Port GPIOE
#define SW_WP_SPD2_Pin GPIO_PIN_3
#define SW_WP_SPD2_GPIO_Port GPIOE
#define SW_WP_SPD1_Pin GPIO_PIN_4
#define SW_WP_SPD1_GPIO_Port GPIOE
#define SW_WP_INT_Pin GPIO_PIN_5
#define SW_WP_INT_GPIO_Port GPIOE
#define SW_POMPA_Pin GPIO_PIN_6
#define SW_POMPA_GPIO_Port GPIOE
#define LM_WIPER_Pin GPIO_PIN_13
#define LM_WIPER_GPIO_Port GPIOC
#define DF_TX_Pin GPIO_PIN_0
#define DF_TX_GPIO_Port GPIOA
#define DF_RX_Pin GPIO_PIN_1
#define DF_RX_GPIO_Port GPIOA
#define BELL_Pin GPIO_PIN_6
#define BELL_GPIO_Port GPIOA
#define POMPA_Pin GPIO_PIN_7
#define POMPA_GPIO_Port GPIOA
#define DEKAT_Pin GPIO_PIN_4
#define DEKAT_GPIO_Port GPIOC
#define JAUH_Pin GPIO_PIN_5
#define JAUH_GPIO_Port GPIOC
#define RETKA_Pin GPIO_PIN_0
#define RETKA_GPIO_Port GPIOB
#define RETKI_Pin GPIO_PIN_1
#define RETKI_GPIO_Port GPIOB
#define WIPER_Pin GPIO_PIN_2
#define WIPER_GPIO_Port GPIOB
#define DIR_Pin GPIO_PIN_15
#define DIR_GPIO_Port GPIOD
#define STEP_Pin GPIO_PIN_6
#define STEP_GPIO_Port GPIOC
#define M2_Pin GPIO_PIN_7
#define M2_GPIO_Port GPIOC
#define M1_Pin GPIO_PIN_8
#define M1_GPIO_Port GPIOC
#define M0_Pin GPIO_PIN_9
#define M0_GPIO_Port GPIOC
#define SW_BEL_Pin GPIO_PIN_7
#define SW_BEL_GPIO_Port GPIOD
#define SW_DIM_Pin GPIO_PIN_3
#define SW_DIM_GPIO_Port GPIOB
#define SW_LJ_Pin GPIO_PIN_4
#define SW_LJ_GPIO_Port GPIOB
#define SW_LD_Pin GPIO_PIN_5
#define SW_LD_GPIO_Port GPIOB
#define SW_RETKI_Pin GPIO_PIN_7
#define SW_RETKI_GPIO_Port GPIOB
#define NXT_RX_Pin GPIO_PIN_0
#define NXT_RX_GPIO_Port GPIOE
#define NXT_TX_Pin GPIO_PIN_1
#define NXT_TX_GPIO_Port GPIOE

/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
