/*
 * dfplayer.h
 *
 *  Created on: Apr 11, 2025
 *      Author: nakanomiku
 */

#ifndef INC_DFPLAYER_H_
#define INC_DFPLAYER_H_

#include "stm32h7xx_hal.h"

extern UART_HandleTypeDef huart4;
#define DF_uart &huart4

// Format constants
typedef enum {
    START_BYTE = 0x7E,
    VERSION = 0xFF,
    LENGTH = 0x06,
    END_BYTE = 0xEF,
    FEEDBACK = 0x00
} DFPlayer_Format;

// Command constants
typedef enum {
    CMD_NEXT = 0x01,
    CMD_PREVIOUS = 0x02,
    CMD_SPECIFY_TRACKING = 0x03, // 0 - 2999
    CMD_INCREASE_VOLUME = 0x04,
    CMD_DECREASE_VOLUME = 0x05,
    CMD_SPECIFY_VOLUME = 0x06,   // 0 - 30
    CMD_SPECIFY_EQ = 0x07,
    CMD_SPECIFY_PLAYBACK_MODE = 0x08,
    CMD_SPECIFY_PLAYBACK_SOURCE = 0x09,
    CMD_ENTER_STANDBY = 0x0A,
    CMD_NORMAL_WORKING = 0x0B,
    CMD_RESET_MODULE = 0x0C,
    CMD_PLAYBACK = 0x0D,
    CMD_PAUSE = 0x0E,
    CMD_SPECIFY_FOLDER_PLAYBACK = 0x0F,
    CMD_VOLUME_ADJUST_SET = 0x10,
    CMD_REPEAT_PLAY = 0x11
} DFPlayer_Command;

// Playback sources
typedef enum {
    PLAYBACK_SOURCE_USB = 0,
    PLAYBACK_SOURCE_TF = 1,
    PLAYBACK_SOURCE_AUX = 2,
    PLAYBACK_SOURCE_SLEEP = 3,
    PLAYBACK_SOURCE_FLASH = 4
} PlaybackSource;

// Function declarations
void DFPlayer_Init(PlaybackSource source, uint8_t volume);
void DFPlayer_SendCmd(DFPlayer_Command command, uint8_t param1, uint8_t param2);
void DFPlayer_PlayNext(void);
void DFPlayer_PlayPrevious(void);
void DFPlayer_Pause(void);
void DFPlayer_PlayTrack(uint16_t trackNumber);

#endif /* INC_DFPLAYER_H_ */