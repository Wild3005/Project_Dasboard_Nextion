/*
 * stepper.h
 *
 *  Created on: Apr 16, 2025
 *      Author: nakanomiku
 */

#ifndef INC_STEPPER_H_
#define INC_STEPPER_H_

#include "tim.h"

typedef struct drv8825 {
	// GPIO Dir
    GPIO_TypeDef * Dir_GPIOx;
    uint16_t Dir_GPIO_Pin;


    // GPIO En
    GPIO_TypeDef * En_GPIOx;
    uint16_t En_GPIO_Pin;

    // TIM Step
    TIM_HandleTypeDef* Timer_Handle;
    uint32_t Timer_Channel;

    // Mode
    uint8_t mode;
} drv8825;

/* End of exported types ----------------------------------------------------*/

/* Exported macros ----------------------------------------------------------*/

#define STEPS_PER_REV	200
#define TIMER_CLOCK		275000000

// Mode macros (Microstep Resolution)
#define MS_RES_1	1
#define MS_RES_2	2
#define MS_RES_4	4
#define MS_RES_8	8
#define MS_RES_16	16
#define MS_RES_32	32

// Dir macros
#define DIR_FORWARD 	1
#define DIR_BACKWARD 	0

// En macros
#define EN_START	0
#define EN_STOP 	1

/* End of exported macros ---------------------------------------------------*/


/* Exported functions -------------------------------------------------------*/
void drv8825_init(drv8825 *drv8825,
		GPIO_TypeDef* Dir_GPIOx, uint16_t Dir_GPIO_Pin,
		GPIO_TypeDef * En_GPIOx, uint16_t En_GPIO_Pin,
		TIM_HandleTypeDef* Timer_Handle, uint32_t Timer_Channel);
uint8_t drv8825_setMode(drv8825 *drv8825, uint8_t mode);
void drv8825_setDir(drv8825* drv8825, uint8_t dir);
void drv8825_setEn(drv8825* drv8825, uint8_t enable);
void drv8825_setSpeedRPM(drv8825* drv8825, uint8_t rpm);


#endif /* INC_STEPPER_H_ */
