/*
 * nextion.h
 *
 *  Created on: Apr 16, 2025
 *      Author: nakanomiku
 */

#ifndef INC_NEXTION_H_
#define INC_NEXTION_H_


#include "stm32h7xx_hal.h"
#include "string.h"
#include "stdio.h"

extern UART_HandleTypeDef huart8;

typedef struct
{
    void (*send_command)(const char *cmd);
    void (*set_text)(int id, const char *text);
    void (*set_num_val)(int id, int value);
    int  (*recv_num)(void);
    int  (*get_num_val)(int id);
    void (*set_float_val)(int id, int value);
    void (*set_picture)(int id, int value);
    void (*set_button_text)(int id, const char *text);
    void (*set_checkbox_value)(int id, int value);
    void (*set_DSbutton_value)(int id, int value);
    void (*set_DSbutton_text)(int id, const char *text);
    void (*set_gauge_value)(int id, int value);
    void (*set_progressbar_value)(int id, int value);
    void (*set_radio_value)(int id, int value);
    void (*set_variable_value)(int id, int value);
    void (*set_variable_text)(int id, const char *text);
} Nextion;

extern char end_command[3];

extern Nextion nextion;

#endif /* INC_NEXTION_H_ */
